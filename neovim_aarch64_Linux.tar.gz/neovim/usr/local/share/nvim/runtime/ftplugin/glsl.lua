vim.bo.commentstring = '// %s'
